# /index.py

from flask import Flask, request, jsonify, render_template, session
import json
#import mysql.connector
import pandas

app = Flask(__name__)
app.secret_key = "123"

val='test'
df = pandas.DataFrame({'complete_url':['about-us','contact-us','services', 'pricing'],
                   'bounce_rate':['30%','70%','10%','45%']})
#print(df)

@app.route('/Simulation',methods=['GET','POST'])
def Simulation():
    # global val, df
    # if request.method == 'POST':
    #         val = request.form['aval']
    #         print("page selected in drop down: " + val)
    #         bounce_rate =df.loc[df['complete_url'] == val, 'bounce_rate'].iloc[0]
    #         print("value to be returned to Actuals label: " + bounce_rate)
    #         return jsonify({'aval':bounce_rate})
    #         # return render_template('index.html', result=bounce_rate,display_table=df)

    # else:
        return render_template('Simulation.html', display_table=df)

@app.route('/')
def index():
    return render_template("Simulation.html", display_table = df)


@app.route('/simulation_test', methods= ['GET', 'POST'])
def simulation_test():
    if(request.method == 'GET'):

        page = request.args.get("page")
        bounce_rate = df.loc[df['complete_url'] == page, 'bounce_rate'].iloc[0]
        return jsonify({
            "bounce_rate": bounce_rate
        })
    elif (request.method == 'POST'):
        bounce_rate_data = float(request.form["bounce_rate_sim"])
        search_input = float(request.form["search_input"])
        chance = bounce_rate_data + search_input
        return jsonify(
            {
                "chance": chance,
                "bounce_rate_sim" : bounce_rate_data,
                "search_input": search_input
            })


# run Flask app
if __name__ == "__main__":
    app.run(debug=True, threaded=True)